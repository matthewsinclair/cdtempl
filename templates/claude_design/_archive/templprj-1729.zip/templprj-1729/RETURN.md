---
verblock: "29 Jul 2026:v1: claude-design - Round two: the probe"
venture: templprj
round: 2
---
# Return — templprj, round 2

## What is in this drop

The probe, as agreed: the neutral kit plus one Form C asset, and nothing else.

| What | Status |
|---|---|
| The mandated layout, as a folder | Demonstrated at this directory's root |
| `kit/` — kit.md, tokens.css, tokens.json | Complete at `kit_version: 1` |
| `assets/pitch-deck/` | Template complete, `status: spec-only`, 47 blanks |
| `exports/pitch-deck.pptx` | Generated from source, as the export-path proof |
| `notes/tokens-and-artefacts.md` | One durable note — see below |

The structure survived one asset end to end. The remaining seven Tier 1 assets
are batch work against a proven shape, with one amendment noted below.

## Revisions to understanding

**The kit cannot be a single file, and calling it one was wrong.** Round one said
"one neutral kit that every template imports," and I argued for it on the
grounds that it makes "is this too charming" a question about one file. That
argument still holds for the *specification*. It does not hold for the
*mechanism*, and building the deck is what showed the difference.

Built HTML artefacts have to restate token values literally rather than link the
stylesheet — they must open standalone from a zip on someone's laptop, and
inline values paint immediately where a stylesheet defers everything until it
arrives. So `#c4c4c4` appears in the deck where an application would write
`var(--line)`. The kit is one file plus N copies, and copies drift.

This does not break the argument, but it moves where the argument is won: from
"one file to review" to "one check to run." Full reasoning and the proposed
fourth `vboot check` rule are in `notes/tokens-and-artefacts.md`. If only one of
the four rules gets built, it should be that one — it is the rule that makes
neutrality a property of the repository rather than of whoever last touched a
file.

**The illustrative marker had to be specified before it could be used.** Round
one identified gap 8.3.3 as a recurring failure and you promoted it to a check
rule. Building the traction slide showed the gap was one level deeper: a check
can only test for a marker that has a defined form. It is now specified in
`kit.md` — monospace, hairline, the literal word, adjacent to the number rather
than in a footnote. Worth noting because it generalises: several of the ten gaps
in §8.3 will turn out to need a specified artefact before they can be checked,
and finding that out while building is cheaper than finding it out while
checking.

## Decisions I made that you did not ask me to make

1. **Thirteen slides, in the settled seed sequence.** The brief did not name a
   length and there is a standard shape, so I used it and said so in the spec
   rather than inventing a house variant.
2. **Slide guidance lives in `data-speaker-notes`, not on the slides.** So the
   template looks like a deck rather than like instructions, and the guidance
   does not have to be deleted before the deck is shown. It also travels with a
   slide when slides are reordered.
3. **The display scale continues past `--text-3xl`** at the same 1.25 ratio, to
   `61 / 76 / 95 / 119`. The round-one scale topped out at 49px, which is too
   small for a 1920-wide title. Extension rather than exception.
4. **`REPLACE` / `KEEP` markers in `tokens.css`.** Not asked for. A venture
   replacing the kit needs to know which values are seams and which are
   structural, and the alternative is a separate document that drifts.
5. **The hatch is a stated exception to prohibition 1.** The placeholder hatch is
   a repeating hard-edged pattern, which is a gradient function but not a colour
   transition. I narrowed the prohibition to blends and named the exception
   rather than leaving the contradiction for someone to discover.
6. **`status: spec-only` for every asset in `templprj`.** A template with
   `status: complete` would be a filled-in template, which is a venture's
   artefact. Recorded in `index.md` so `vboot check` can rely on it.
7. **Three tweakable props on the deck** — venture name, stage, and whether
   illustrative markers show. The first two write through to every slide that
   mentions them, which is the case where a control beats editing thirteen
   places by hand.

## What I could not do, and why

- **No PDF in `exports/`.** PDF generation is a print action that has to be
  taken on your side; the deck is print-ready and one action away. The PPTX is
  there as the export-path proof.
- **No logo anywhere in the deck**, including the cover and the close. Correct
  per Form D, but worth stating: the cover has a hatched mark slot rather than a
  placeholder mark, because a placeholder mark is the thing that survives.
- **The competition slide has a structure but no axis.** The axis is the argument
  and it is wholly venture-specific. The template gives four rows and four
  columns and a note; it cannot give the comparison.

## What I would do next

Batch the remaining seven Tier 1 assets, in this order, and for one structural
reason each:

1. **`positioning-icp-personas`** — Form A, and the cheapest. It proves the Form
   A pattern and it is what the deck's blanks are waiting on.
2. **`whos-who-in-the-zoo`** — Form A with hatched imagery. Proves that the two
   kinds of blank coexist in a document rather than only in a deck.
3. **`design-system`** — the big one, and the only asset that is a directory of
   many files rather than one. It is the real test of whether the uniform asset
   shape holds, and if anything in the structure is going to break it is here.
4. **`brand-guidelines`**, **`product-one-pager`**, **`landing-page`**,
   **`investor-update`** — batch work once 3 has landed.

The amendment: do 3 third rather than last. It is the asset most likely to
require a structural change, and the argument for probing early does not stop
applying just because the first probe passed.
