---
verblock: "29 Jul 2026:v1: claude-design - Surfaced while building the pitch deck probe"
---
# Tokens and built artefacts: a drift risk, and the check that closes it

Surfaced by the round-two probe. Durable, so it is here rather than only in
`RETURN.md`.

## The situation

The kit exists in two forms and is consumed in three ways.

1. `kit/tokens.css` — custom properties. Consumed directly by the venture's
   application: Tailwind theme, daisyUI theme, `assets/css/`. This is the path
   the architecture was designed for and it works as intended.
2. `kit/tokens.json` — the same values, parseable. Consumed by any build step or
   script that needs them without parsing CSS.
3. **Built HTML artefacts** — the decks, galleries and pages of Form C. These
   **restate the values literally** rather than linking the stylesheet.

Point 3 is the one worth writing down.

## Why artefacts restate rather than import

Two reasons, and the first is not negotiable from my side.

**Artefacts must open standalone.** A deck that a partner opens from a zip on a
laptop with no server cannot depend on a relative stylesheet two directories up
resolving. The moment it is emailed, moved, or opened from a download folder,
a linked `../../kit/tokens.css` is a blank page. An artefact that only works
in place is an artefact that will be seen broken.

**Values inline paint immediately.** A stylesheet defers everything the reader
sees until both the rules and the markup have arrived. For a deck this is the
difference between a slide appearing and a white rectangle appearing.

So `#c4c4c4` appears literally in the pitch deck, in the place where an
application would write `var(--line)`.

## The cost

The kit and the artefacts can drift. Someone edits `--grey-300` in
`tokens.css`, the deck keeps the old value, and nobody notices because both look
grey. This is exactly the failure class the kit was built to prevent, arriving
by a different door.

Handling it by care does not work, for the same reason the prohibitions exist.

## The check

A fourth rule for `vboot check`, and mechanically the cheapest of the four:

> **Every colour literal appearing in any artefact must appear in
> `kit/tokens.json`.**

Grep every `#rrggbb` and `rgb()` in `assets/**`, resolve against the ramp in
`tokens.json`, fail on anything unmatched.

This catches both directions of the problem at once:

- **Drift** — an artefact holding a value the kit no longer contains.
- **Smuggling** — a hue entering an artefact without passing through the kit,
  which is prohibition 4 becoming enforceable rather than aspirational.

The second is the more valuable of the two. It is the single check that makes
neutrality a property of the repository rather than a property of whoever last
touched it. If only one of the four rules gets built, build this one.

## A related rule not worth building

Font stacks could be checked the same way, but there is one stack and it appears
in one form. Checking it would be ceremony. Colour is worth checking because
there are twelve values, they are indistinguishable by eye, and a hue is exactly
what someone adds when they are trying to be helpful.
