---
verblock: "29 Jul 2026:v1: claude-design - Round two probe: kit plus one Form C asset"
venture: templprj
round: 2
spec_library_version: 1
target_structure_version: 1
kit_version: 1
---
# Manifest

What is in this drop, and what state it is in. Read `RETURN.md` first.

## Assets

| Slug | Name | Form | Tier | Status | Spec | Blanks | Waiting on |
|---|---|---|---|---|---|---|---|
| `pitch-deck` | Pitch deck | C | 1 | spec-only | 1 | 47 | 7 inputs — see its `spec.md` |

`status: spec-only` is correct for a template and is the state every asset in
`templprj` stays in. A template with `status: complete` would be a template
that had been filled in, which is a venture's artefact and not this directory's.

## Kit

| File | What it is |
|---|---|
| `kit/kit.md` | The kit written down: ramp, type, blanks, prohibitions |
| `kit/tokens.css` | Custom properties, `REPLACE`/`KEEP` marked |
| `kit/tokens.json` | The same values, parseable |

## Notes

| File | What it is |
|---|---|
| `notes/tokens-and-artefacts.md` | Why artefacts restate token values, the drift this creates, and the check that closes it |

## Grouping

Grouping lives here rather than in the directory tree, per the round-one
structure argument. With one asset present there is nothing to group yet; the
columns above are the shape it will take.

Bundles this drop touches: **seed-set** (partially — 1 of 6).

## Not yet present

The remaining seven Tier 1 assets, held pending the probe:
`design-system`, `brand-guidelines`, `positioning-icp-personas`,
`product-one-pager`, `landing-page`, `investor-update`, `whos-who-in-the-zoo`.
