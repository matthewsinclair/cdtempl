# exports/

Generated. Never hand-edited.

Both files regenerate from `../Pitch Deck.dc.html`, which is the source of
truth. A hand-edited export is a fork, and the fork wins by accident because it
is the one that gets sent.

| File | What it is for |
|---|---|
| `pitch-deck.pptx` | Editable, native text and shapes, for a venture taking the deck over |
| `pitch-deck.pdf` | The send-ahead version |

The `.pptx` in this directory was generated from the template as the round-two
probe of the export path — it is a deck of blanks, and its only purpose is to
prove the path works end to end. A real venture drop regenerates both.
