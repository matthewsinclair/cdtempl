---
verblock: "29 Jul 2026:v2: claude-design - Round three: findings applied, two assets, stopped at the composite break"
venture: templprj
round: 3
supersedes: "round 2 RETURN.md"
---
# Return — templprj, round 3

## What is in this drop

All four round-two findings applied, two assets built, and a stop at the third.

| What | Status |
|---|---|
| Finding 1 — `vendor/` in the asset shape | Applied, **with one correction to the rule** |
| Finding 2 — `blanks` definition | Settled as occurrences, plus a companion field |
| Finding 3 — "standalone" overstated | Wording corrected in the note |
| Finding 4 — `exports/README.md` | Corrected, and given a state column |
| `assets/positioning-icp-personas/` | Form A, built |
| `assets/whos-who-in-the-zoo/` | Form C, built — **reclassified from Form A** |
| `assets/design-system/` | **Not built. Stopped, per instruction.** |
| `brand-guidelines`, `product-one-pager`, `landing-page`, `investor-update` | Held behind the stop |

## Revisions to understanding

**`design-system` is not an asset, it is a bundle.** This is the stop you asked
for, and the full argument is in `notes/composite-assets.md`.

The break is not mechanical — the directory works fine. It is in the front
matter, which is a check problem: the uniform shape carries one `status`, one
`blanks` and one `inputs_missing` per asset, and a design system is nine things
with independent readiness. A venture with a finished component library and no
data-visualisation standard cannot be described by one status field, and
`blanks: 300` across nine documents estimates nothing. The composite defeats the
mechanism you have just committed to building.

The fix is a simplification and invents nothing: split into flat slugs, one per
taxonomy entry, and let `design-system` be a bundle name — which is where
groupings were already agreed to live. The taxonomy had them separate; round one
collapsed them for Tier 1 convenience, and the structure is rejecting that
convenience.

Two consequences to decide on. **Tier 1 goes from eight assets to eleven**, and
five of the old composite's parts drop to Tier 2 and 3 — which is more honest, and
pretending the design system was atomic is what hid it. **Asset 20 is `kit/`**,
which means one asset legitimately lives at the target root rather than under
`assets/`, and that is better named as a deliberate exception than left as an
inconsistency someone finds later.

**The colour check cannot exclude `vendor/` by path.** Your decision to add
`vendor/` is right and is applied, but the rule that goes with it needed one
change, and it is the same argument you made about exception lists.

Not all runtime can be put in `vendor/`. `deck-stage.js` moved there. `support.js`
cannot: the authoring runtime emits `<script src="./support.js">` as a sibling of
every `.dc.html`, and that path is not the author's to set. A path-based
exclusion therefore needs `support.js` named as a special case — which is the
maintained exception list that prohibitions-over-instructions exists to avoid,
arriving one level down.

**Exclude by declaration instead.** Every vendored file states what it is in its
own first lines — `GENERATED ... do not edit`, `Copied ... starter`. So: skip any
file whose first ten lines match
`GENERATED|do not edit|do not modify|Copied .* starter|@generated`. Better on
three counts: correctness does not depend on anyone having put a file in the right
place; it covers runtime that cannot be moved; and new vendored files arrive
already exempt, so the rule never needs updating. `vendor/` still earns its place
for legibility — 205KB of minified JavaScript beside `spec.md` is illegible, and a
directory says "not yours" to a human at a glance — but the check must not depend
on it.

**Form A can only carry one of the two kinds of blank.** Markdown cannot hatch an
image slot, so any asset whose completeness depends on imagery is **Form C by
construction**. That moved `whos-who-in-the-zoo` out of Form A, where round one
had put it. A markdown zoo would either omit headshots or carry a line of text
saying a photograph goes here — which is a note about a placeholder, not a
placeholder, and it does not look wrong when it is left in. The rule is now in
`kit.md` and should be applied to the rest of the taxonomy as each is templated.

**Vendored runtime that measures on connect needs a post-mount nudge, and this
will recur.** Caught in review rather than by me, on the zoo. `doc-page` measures
its slotted running header and footer on connect and reserves space by setting two
custom properties; the authoring runtime slots those children in after connect, so
both bands stayed at `0px` and the running header drew on top of the first
heading on first paint.

Worth recording for two reasons beyond the fix. It is **invisible in the source** —
the markup is correct and the defect is a timing artefact of the boundary between
vendored runtime and the authoring runtime, so it reads as a layout mistake and
will be looked for in the wrong place. And it is **not specific to this asset**:
every future document asset with running bands inherits it. The pattern is
recorded in that asset's `vendor/README.md`, which is where the next person to
mount `doc-page` will be looking.

It also slightly strengthens the case for a bundled single-file export: a
generated export is a fixed artefact with the measurement already resolved, where
the source depends on two runtimes agreeing about order.

**Confirmation on Finding 2, not defence.** You are right that the blanks count
was wrong and right about what it demonstrates. Settled as you proposed:
`blanks` counts occurrences, because that is the number of substitutions a human
faces. Added `blanks_unique` as the companion field you predicted was needed,
because the two numbers answer different questions and one alone misleads — 62 and
31 for the zoo is a materially different picture from either number by itself.

## Decisions I made that you did not ask me to make

1. **The colour check's exclusions are declaration-based, not path-based.** A
   change to a rule you had already decided. Reasoned above; revert it if the
   reasoning does not hold.
2. **`exports/README.md` gained a state column** rather than having the PDF row
   deleted. A row that says "not generated" is more useful than a silent absence,
   and the state column generalises to every asset's exports.
3. **`vendor/README.md` is the same text in every asset directory**, including the
   paragraph about `support.js`. Duplicated deliberately: the person who finds
   205KB of minified JavaScript is reading that directory, not a central document.
4. **The zoo is a flowing document, not explicitly paginated.** Team size varies,
   and a fixed page count is a lie the first time someone joins.
5. **The zoo orders people by what they own, not by seniority**, and "where
   decisions are written down" is a routing entry. Neither was asked for. The
   document's actual use is finding the right person, and seniority is not an
   index for that.
6. **`positioning-icp-personas` is one document, not three.** Split apart they
   drift within a quarter, the classic symptom being a positioning statement aimed
   at one buyer and a landing page written for another.
7. **Personas carry an evidence label** — evidenced or hypothesised — as a
   required field. An unlabelled hypothesis becomes a fact within two months.
8. **The positioning statement uses the standard template** (Moore, as refined by
   Dunford) rather than a house variant, and the spec says so.

## What I could not do, and why

- **Nothing after `design-system` in the batch order.** Deliberate: you asked me
  to stop at the break rather than work around it, and the shape is cheaper to
  settle now than after four more assets are built against it.
- **No PDF in either `exports/`.** Both artefacts are print-ready; PDF is a print
  action on your side. The zoo is a flowing document, so it paginates onto
  whatever paper the reader actually has.
- **No single-file bundled export yet.** It is the honest answer to Finding 3 —
  the source is directory-portable and a bundled export would be genuinely
  file-portable, which is what emailing one artefact needs. Not built because it
  belongs in `exports/` as generated output, and I would rather add it once for
  all Form C assets than once for the deck.

## Answers to your two questions on Finding 1

**Should the runtime ship at all?** Yes, for the source — the artefact does not
render without it, and an artefact that needs a build step to be looked at will
not be looked at. Three things reduce the cost:

- It is **per Form C asset**, not per venture. Form A assets have no runtime at
  all, and a seed-set drop carries it two or three times, not eleven.
- It should **not** be deduplicated to a shared `$VBOOT_TARGET/vendor/`. That
  saves bytes and reintroduces the two-levels-up fragility that inlining exists to
  avoid. The unit of portability is the asset directory; duplication is the
  correct trade.
- A **bundled single-file export** in `exports/` is where the runtime cost buys
  something back: one file, no siblings, genuinely emailable. That is the right
  place for the inlining, and it is generated rather than source.

**`vendor/README.md`:** written, and in every asset directory that has runtime.
It states what the files are, that they are regenerable, that they must not be
edited, that they are excluded from the colour check and why, and that they must
not be deduplicated to a shared directory. It also names the `support.js`
exception, because the person most likely to be confused by a runtime file that is
*not* in `vendor/` is the person reading `vendor/`.

## What I would do next

Nothing until the composite question is settled — it changes what "the remaining
assets" means.

**If you accept the split**, round four is eight assets, and the order changes:

1. `design-system-index` — Form C, and the cheapest of the three new Tier 1
   items. It is the front door, so building it first surfaces what the other two
   have to declare about themselves.
2. `component-library` — Form C, the largest single artefact in the taxonomy, and
   the one the venture's application actually consumes.
3. `states-and-interaction` — Form C, and directly dependent on 2.
4. `brand-guidelines`, `product-one-pager`, `landing-page`, `investor-update` —
   the four held behind this stop.

**If you reject it**, say what should carry the per-part readiness that the
composite's front matter cannot, and I will build `design-system` as a single
asset against that.
