---
verblock: "29 Jul 2026:v2: claude-design - Round three: two assets, four findings applied, stopped at the composite break"
venture: templprj
round: 3
spec_library_version: 1
target_structure_version: 2
kit_version: 1
---
# Manifest

What is in this drop, and what state it is in. Read `RETURN.md` first.

## Assets

| Slug | Name | Form | Tier | Status | Spec | Blanks | Unique | Waiting on |
|---|---|---|---|---|---|---|---|---|
| `pitch-deck` | Pitch deck | C | 1 | spec-only | 1 | 64 | 45 | 7 inputs |
| `positioning-icp-personas` | Positioning, ICP and personas | A | 1 | spec-only | 1 | 58 | 54 | 4 inputs |
| `whos-who-in-the-zoo` | Who's who in the zoo | C | 1 | spec-only | 2 | 62 | 31 | 6 inputs |

`blanks` counts occurrences, `unique` counts distinct blanks. Occurrences
estimate the substitutions a human faces; unique estimates the decisions. Both are
declared because one without the other misleads.

`status: spec-only` is correct for a template and is the state every asset in
`templprj` stays in. A template with `status: complete` would be a filled-in
template, which is a venture's artefact and not this directory's.

## Kit

| File | What it is |
|---|---|
| `kit/kit.md` | The kit written down: ramp, type, the two blanks, prohibitions |
| `kit/tokens.css` | Custom properties, `REPLACE`/`KEEP` marked |
| `kit/tokens.json` | The same values, parseable |

`kit/` is taxonomy asset 20, design tokens, deliberately living at the target
root rather than under `assets/` because it is the one thing every other asset
imports. See `notes/composite-assets.md`.

## Notes

| File | What it is |
|---|---|
| `notes/tokens-and-artefacts.md` | Why artefacts restate token values, the drift it creates, and the check that closes it — including why the check's exclusions are declaration-based rather than path-based |
| `notes/composite-assets.md` | Why `design-system` is a bundle rather than an asset, and the eight slugs it becomes |

## The asset directory shape, v2

```
assets/<slug>/
  spec.md            definition of done, travelling with the artefact
  <artefact files>
  vendor/            regenerable runtime — not yours to maintain      [new in v2]
  exports/           generated output — never hand-edited
  src/               working files, if any
```

`vendor/` added in round three. One caveat recorded in
`notes/tokens-and-artefacts.md`: `support.js` is emitted by the authoring
runtime as a sibling of each `.dc.html` and cannot be moved into `vendor/`,
which is why the colour check excludes vendored files by declaration rather than
by path.

## Grouping

Bundles this drop touches:

| Bundle | Progress |
|---|---|
| `founding-set` | 2 of 6 — `positioning-icp-personas`, `whos-who-in-the-zoo` |
| `seed-set` | 2 of 6 — `pitch-deck`, `whos-who-in-the-zoo` |

## Not yet present

Held pending the decision in `notes/composite-assets.md`:

`component-library`, `states-and-interaction`, `design-system-index` — the Tier 1
members of the former `design-system` composite.

Held behind that stop, in batch order:

`brand-guidelines`, `product-one-pager`, `landing-page`, `investor-update`.
